module.exports = {
  purge: [],
  darkMode: false, // or 'media' or 'class'
  theme: { 
    extend: {},
  },
  variants: {
    extend: {},
  },
  plugins: [],
};
//check if the config file uploads the colors schemes and text scheme
//use the pdf or color rgba to see