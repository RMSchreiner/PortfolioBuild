TailWind upload to Node.js project
https://javascript.plainenglish.io/get-tailwind-up-running-c454199f72ec
